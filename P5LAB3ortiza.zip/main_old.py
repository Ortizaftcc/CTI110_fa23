# CTI 110
# P5LAB3 Quiz Show
# ortiza
# 11/7/23


import random

def welcome_message():
    print("Welcome to the Quiz Show!")
    print("Answer the questions correctly to score points.")
    print("Let's get started!\n")


def get_question_and_answer(question_set):
    question_keys = list(question_set.keys())
    question_key = random.choice(question_keys)
    question = question_set[question_key]["question"]
    options = question_set[question_key]["options"]
    answer = question_set[question_key]["answer"]
    return question_key, question, options, answer


def ask_question(question, options):
    print(question)
    for index, option in enumerate(options, start=1):
        print(f"{index}. {option}")
    user_answer = input("Enter your answer (number): ")
    return int(user_answer) - 1


def check_answer(user_answer, correct_answer):
    return user_answer == correct_answer


def show_score(score):
    print("Your current score is:", score)


def goodbye_message(score):
    print("Thank you for playing!")
    print("Your final score is:", score)


def play_quiz(question_set):
    score = 0
    total_questions = len(question_set)
    
    welcome_message()
    while question_set:
        question_key, question, options, answer = get_question_and_answer(question_set)
        user_answer = ask_question(question, options)
        
        if check_answer(user_answer, answer):
            score += 1
            print("Correct!")
            print()
        else:
            print("Incorrect!")
            print()
        
        del question_set[question_key]
        show_score(score)
    
    goodbye_message(score)


question_set = {
    "Q1": {
        "question": "When was Terraria first released?",
        "options": ["2010", "2011", "2012", "2013"],
        "answer": 1
    },
    "Q2": {
        "question": "What is the main objective of Terraria?",
        "options": ["Survive and defeat bosses", "Build structures and cities", "Solve puzzles and riddles", "Complete quests and missions"],
        "answer": 0
    },
    "Q3": {
        "question": "Which of the following is not a playable class in Terraria?",
        "options": ["Warrior", "Mage", "Ranger", "Engineer"],
        "answer": 3
    },
    "Q4": {
        "question": "Which biome features a floating island in Terraria?",
        "options": ["Jungle", "Desert", "Ocean", "Sky"],
        "answer": 3
    },
    "Q5": {
        "question": "What item is required to summon the Eye of Cthulhu boss in Terraria?",
        "options": ["Suspicious Looking Eye", "Worm Food", "Bloody Spine", "Mechanical Eye"],
        "answer": 0
    },
    "Q6": {
        "question": "Which hardmode boss drops the Excalibur sword in Terraria?",
        "options": ["The Twins", "The Destroyer", "Skeletron Prime", "Plantera"],
        "answer": 2
    },
    "Q7": {
        "question": "Which NPC sells wings in Terraria?",
        "options": ["Arms Dealer", "Goblin Tinkerer", "Dryad", "Witch Doctor"],
        "answer": 1
    },
    "Q8": {
        "question": "Which biome contains hardmode ore deposits in Terraria?",
        "options": ["Forest", "Cavern", "Corruption", "Underground Hallow"],
        "answer": 2
    },
    "Q9": {
        "question": "Which boss drops the Pwnhammer, used to break demon altars in Terraria?",
        "options": ["Golem", "The Wall of Flesh", "Plantera", "The Destroyer"],
        "answer": 1
    },
    "Q10": {
        "question": "Which event causes the Pirate Invasion in Terraria?",
        "options": ["Halloween", "Christmas", "Frost Moon", "Pirate Map"],
        "answer": 3
    }
}