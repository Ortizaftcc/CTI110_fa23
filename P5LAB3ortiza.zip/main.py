# CTI 110
# P5LAB3 Quiz Show
# ortiza
# 11/7/23


import random

def welcome_message():
    print("Welcome to the Quiz Show!")
    print("Answer the questions correctly to score points.")
    print("Let's get started!\n")


def get_question_and_answer(question_set):
    question_keys = list(question_set.keys())
    question_key = random.choice(question_keys)
    question = question_set[question_key]["question"]
    options = question_set[question_key]["options"]
    answer = question_set[question_key]["answer"]
    return question_key, question, options, answer


def ask_question(question, options):
    print(question)
    for index, option in enumerate(options, start=1):
        print(f"{index}. {option}")
    user_answer = input("Enter your answer (number): ")
    return int(user_answer) - 1


def check_answer(user_answer, correct_answer):
    return user_answer == correct_answer


def show_score(score):
    print("Your current score is:", score)


def goodbye_message(score):
    print("Thank you for playing!")
    print("Your final score is:", score)


def play_quiz(question_set):
    score = 0
    total_questions = len(question_set)
    
    welcome_message()
    while question_set:
        question_key, question, options, answer = get_question_and_answer(question_set)
        user_answer = ask_question(question, options)
        
        if check_answer(user_answer, answer):
            score += 1
            print("Correct!")
            print()
        else:
            print("Incorrect!")
            print()
        
        del question_set[question_key]
        show_score(score)
    
    goodbye_message(score)


question_set = {
    "Q1": {
        "question": "What year was Cruelty Squad released?",
        "options": ["2020", "2019", "2021", "2018"],
        "answer": 0
    },
    "Q2": {
        "question": "Who developed Cruelty Squad?",
        "options": ["Replit", "Steam", "Valve", "Consumer Softproducts"],
        "answer": 3
    },
    "Q3": {
        "question": "What is the main objective of the game Cruelty Squad?",
        "options": ["Rescue hostages", "Solve puzzles", "Assassinate targets", "Explore a cyberpunk city"],
        "answer": 2
    },
    "Q4": {
        "question": "What genre does Cruelty Squad primarily belong to?",
        "options": ["Racing", "Simulation", "First-person shooter", "Role-playing"],
        "answer": 2
    },
    "Q5": {
        "question": "Name one of the weapons commonly used in Cruelty Squad.",
        "options": ["Knife", "Frying pan", "Crossbow", "Silenced pistol"],
        "answer": 0
    }
}

play_quiz(question_set)

