"""
This is the Template Repl for Python with Turtle.

Python with Turtle lets you make graphics easily in Python.

Check out the official docs here: https://docs.python.org/3/library/turtle.html
"""

import turtle

t = turtle.Turtle()
# Comment block
"""
for c in ['red', 'green', 'blue', 'purple']:
    t.color(c)
    t.forward(75)
    t.left(90)
"""
"""
#trapizoid
t.color("blue")
t.pensize(3)
t.forward(200)

t.color("green")
t.pensize(3)
t.left(120)
t.forward(100)

t.color("black")
t.pensize(3)
t.left(60)
t.forward(100)

t.color("purple")
t.pensize(3)
t.left(60)
t.forward(100)
"""
#My initials
t.color("black")
t.pensize(3)
t.left(66)
t.forward(100)

t.color("black")
t.right(132)
t.forward(45)

t.color("black")
t.right(114)
t.forward(37)

t.color("black")
t.right(0)
t.forward(-37)

t.color("black")
t.left(114)
t.forward(55)

t.color("black")
t.penup()
t.left(65)
t.forward(75)

t.color("black")
t.pendown()
t.circle(45)