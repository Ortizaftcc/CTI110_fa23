num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

value = num1 * num2 * num3 * num4
average = (num1 + num2 + num3 + num4) / 4 

print(f'{value:.0f} {average:.0f}')

print(f'{value:.3f} {average:.3f}')

