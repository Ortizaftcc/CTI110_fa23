from flask import Flask

app = Flask(__name__)


@app.route('/')
def index():
    return """
  


<h1>Hello from yours truly!</h1>

<h3>Tutorial</h3>

<p>I ate a tub of lard.</p>
<p>it wasnt very good</p>

"""


app.run(host='0.0.0.0', port=81)
