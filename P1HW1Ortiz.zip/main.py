"""
CTI 110
P1HW1 - Variables
Ortiza
9/5/23

Do some basic output with numbers
1. ask for an int
2. square it and then cube it
3. ask for an int
4. add them and multiply them

"""
#part 1: numbers
# variables, first and second
first = 0
second = 0

print("enter integer:")
first = int(input()) # take input, then convert to int
print(first, "squared is", first * first)
print("and", first, "cubed is", first * first * first, "!!")

#get another int
print("Enter another integer:")
second = int(input())
#to do: print the number, not the words first and second
print(first, "+", second, "=", first + second)
print(first, "*", second, "=", first * second)


#part 2: movies
#Three variables
#string - movie name
#int - year of the movie
#float - the gross (in millio dollars)
#finally print a quote

name = "john wick"
name1 = "Iosef Tarasov:"
name2 = "Kirill:"
year = 2014
gross = 86.08 #mil $
quote1 = name1, "Are you scared of the fuckin' Boogie man? I'm not."
quote2 = name2, "No? Well you should be"
#print out this information
#then print out quote
print(name, "released in", year, "it has made approximately", gross, "$", "in", year)
print(quote1)
print(quote2)