# CTI-110 
# P5HW1 - Math Quiz
# Ortiza
# 11-21-23








import random

def generate_numbers():
    return random.randint(1, 100), random.randint(1, 100)

def display_question(operator, num1, num2):
    print(f"{num1} {operator} {num2}")

def get_user_answer():
    return int(input("Enter your answer: "))

def math_quiz(operator):
    num1, num2 = generate_numbers()
    display_question(operator, num1, num2)

    correct_answer = num1 + num2 if operator == '+' else num1 - num2
    num_guesses = 0

    while True:
        user_answer = get_user_answer()
        num_guesses += 1

        if user_answer == correct_answer:
            print(f"Congratulations! That's correct. It took you {num_guesses} guesses.")
            break
        else:
            print("Incorrect! Try again.")

def main():
    print("Welcome to the Math Quiz!")

    while True:
        print("MENU:")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Exit")

        choice = input("Enter your choice (1, 2, or 3): ")

        if choice == '1':
            math_quiz('+')
        elif choice == '2':
            math_quiz('-')
        elif choice == '3':
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()