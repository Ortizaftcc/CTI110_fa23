# CTI-110 
# P5HW1 - Math Quiz
# Ortiza
# 11-21-23








import random

def random_number():
    num1 = random.randint(1, 150)
    num2 = random.randint(1, 150)
    return num1, num2

def display_addition_question(num1, num2):
    print(f"{num1} + {num2}")

def display_subtraction_question(num1, num2):
    print(f"{num1} - {num2}")

def get_user_answer():
    return int(input("Enter your answer: "))

def math_quiz_addition():
    num_guesses = 0

    while True:
        num1, num2 = random_number()
        display_addition_question(num1, num2)

        correct_answer = num1 + num2
        user_answer = get_user_answer()
        num_guesses += 1

        if user_answer == correct_answer:
            print(f"Congratulations! That's correct. It took you {num_guesses} guesses.")
            break
        else:
            if user_answer < correct_answer:
                print("Too low! Try again.")
            else:
                print("Too high! Try again.")

def math_quiz_subtraction():
    num_guesses = 0

    while True:
        num1, num2 = random_number()
        display_subtraction_question(num1, num2)

        correct_answer = max(num1, num2) - min(num1, num2)
        user_answer = get_user_answer()
        num_guesses += 1

        if user_answer == correct_answer:
            print(f"Congratulations! That's correct. It took you {num_guesses} guesses.")
            break
        else:
            print("Incorrect! Try again.")

def main():
    while True:
        print("MENU:")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Exit")

        choice = input("Enter your choice (1, 2, or 3): ")

        if choice == '1':
            math_quiz_addition()
        elif choice == '2':
            math_quiz_subtraction()
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    print("Welcome to the Math Quiz!")
    main()